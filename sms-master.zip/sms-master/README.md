# SPAM SMS Unlimited
![image](https://github.com/Xractz/SMS/blob/master/spam.png)
SPAM SMS menggunakan api web INDIHOME dengan menggunakan bahasa pemrograman python

## Cara Install Termux
```
$pkg install git
$pkg install python3
$pip install requests
$git clone https://github.com/Xractz/SMS
$cd sms
$python spam.py
```


## Cara Install Linux
```
$sudo apt-get install git
$sudo apt-get install python3
$pip install requests
$git clone https://github.com/Xractz/SMS
$cd sms
$python spam.py
```

Copyright © 2020, Xractz - IndoSec



